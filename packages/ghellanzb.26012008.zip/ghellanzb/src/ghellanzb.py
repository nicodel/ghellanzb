#!/usr/bin/python
# -*- coding: UTF-8 -*-

###########################
# TODO: Create a dictionary file for translations
# TODO: Create a view for the hellanzb logs
# TODO: Validate the "startup in tray" options and find a location to store it. The best way will be to create a option within the Hellanzb Preferences.
# TODO: During the launch, test the hellanzb.conf file to be sure that the options that will be displayed in the preferences window are not commented
# TODO: in order to be able to write the hellanzb.conf we will need to create our own and launch hellanzb using it
#	os.system(self.hellaInstallFile + " -c " + self.strSettingsDir  + "hellanzb.conf -D")
#############################

import pygtk, gtk, sys
pygtk.require('2.0')

from xmlrpclib import ServerProxy
from time import sleep
import threading, gobject
import Hellanzb, Hellanzb.PostProcessor
from Hellanzb.Util import *
from Hellanzb.Core import *

Hellanzb.SERVERS = {}

class ghellanzb(threading.Thread):
	'''
	
	'''
	
	def __init__(self):
		'''
		
		'''
		print "let's load"
		
		#Let's initiate some variables
		self.runner = 1
		self.update = 0
		self.pause = 0
		self.window_show = 1
		self.current_queue = gtk.ListStore(str, str, str, int, str, int)
		self.buffer_downloading = {}
		self.buffer_queued = {}
		self.buffer_processing = {}
		self.downloading = {}
		self.queued = []
		self.processing = []
		self.done = []
		
		#Let's thread
		super(ghellanzb, self).__init__()
		
		#Let's give us the rigth to modify the hellanzb.conf file
		#os.system('chmod' )
				
		#Let's check the hellanzb connectivity and hellanzb.conf options
		try : self.connect()
		except : print "Please check that hellanzb is running"
				
		try : self.get_preferences()
		except : print "Please check that all options are uncommented in the hellanzb.conf file"
		
		#Let's display
		self.create_main_window()
	
	def run(self):
		'''
		
		'''
		while self.runner:
			#print "self.runner is %s" % self.runner
			self.update_queue()
			sleep(1)

	def create_main_window(self):
		'''
		
		'''

		self.update_queue()

		#Create the Main Window and set the title..
		self.MainWindow = gtk.Window(gtk.WINDOW_TOPLEVEL)
		#self.MainWindow.set_size_request(700, 325)    
		self.MainWindow.set_title("ghellanzb")
		#self.MainWindow.set_icon_from_file("icon.png")
		self.MainWindow.set_position(gtk.WIN_POS_CENTER)
			
		self.MainWindow.connect("destroy", self.destroy, self.MainWindow)
		# TODO: Hide the window when the Minimize button is pressed
		#self.MainWindow.connect('minimiezd', self.hide_window, self.MainWindow)

		#Here we create the mainVBox
		MainBoxV = gtk.VBox(False,0)
		self.MainWindow.add(MainBoxV)
		
		MainToolbar = gtk.Toolbar()
		MainBoxV.pack_start(MainToolbar, False, True, 0)
		MainToolbar.show()
		
		AddButton = gtk.ToolButton(gtk.STOCK_ADD)
		MainToolbar.add(AddButton)
		AddButton.connect_object("clicked", self.open_add_file_window, False)

		RemoveButton = gtk.ToolButton(gtk.STOCK_REMOVE)
		MainToolbar.add(RemoveButton)
		RemoveButton.connect_object("clicked", self.delete_from_queue, None)
		
		Separator1 = gtk.SeparatorToolItem()
		#Separator1.show()        
		MainToolbar.add(Separator1)
		
		#The Up button
		UpButton = gtk.ToolButton(gtk.STOCK_GO_UP)
		MainToolbar.add(UpButton)
		UpButton.connect_object("clicked", self.move_in_queue, True)

		DownButton = gtk.ToolButton(gtk.STOCK_GO_DOWN)
		MainToolbar.add(DownButton)
		DownButton.connect_object("clicked", self.move_in_queue, False)

		PauseButton = gtk.ToolButton(gtk.STOCK_MEDIA_PAUSE)
		MainToolbar.add(PauseButton)
		PauseButton.connect_object("clicked", self.pause_download, None)

		Separator2 = gtk.SeparatorToolItem()     
		MainToolbar.add(Separator2)

		RefreshButton = gtk.ToolButton(gtk.STOCK_REFRESH)
		MainToolbar.add(RefreshButton)
		RefreshButton.connect('clicked', self.refresh, False)

		#gtk.stock_add([(gtk.STOCK_CLEAR, "Clear Finished", 0, 0, "")])
		#ClearButton = gtk.ToolButton(gtk.STOCK_CLEAR)
		#MainToolbar.add(ClearButton)
		#ClearButton.connect_object("clicked", self.clearFinished, False)
		
		PreferencesButton = gtk.ToolButton(gtk.STOCK_PREFERENCES)
		MainToolbar.add(PreferencesButton)
		PreferencesButton.connect_object("clicked", self.open_preferences_window, None)
		
		Separator3 = gtk.SeparatorToolItem()   
		MainToolbar.add(Separator3)

		QuitButton = gtk.ToolButton(gtk.STOCK_QUIT)
		MainToolbar.add(QuitButton)
		QuitButton.connect_object("clicked", self.destroy, QuitButton)
		
		MainVPaned = gtk.VPaned()
		#MainVPaned.show()

		self.QueueTree = gtk.TreeView(self.current_queue)
		self.QueueTree.set_rules_hint(True)
		
		#QueueTree.enable_model_drag_dest([('text/plain', 0, 0)], gtk.gdk.ACTION_DEFAULT | gtk.gdk.ACTION_MOVE)
		#QueueTree.connect("drag_data_received", self.dragFile)
		#self.QueueTree.show()

		self.add_column_to_treeview("Name",0)
		self.add_column_to_treeview("Total Size (MB)",1)
		self.add_column_to_treeview("Time",2)

		self.add_progressbar_to_treeview("Progress", 4, 3)

		MainScroll = gtk.ScrolledWindow()
		MainScroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
		MainScroll.set_size_request(650, 200)
		#MainScroll.show()
		#MainScroll.add(QueueTree)
		MainScroll.add_with_viewport(self.QueueTree)

		MainBoxV.pack_start(MainScroll, True, True, 0)
		
		MainBottom = gtk.Expander(label="Advanced information:")
		#MainBottom.show()
		MainBottomHBox = gtk.HBox()
		#MainBottomHBox.show()
		MainBoxV.pack_end(MainBottom, False, False, 5)
		MainBottomLabel = gtk.Label("Nothing to download")
		#MainBottomLabel.show()
		
		MainBottomFrame = gtk.Frame("Statistics")
		#MainBottomFrame.show()
		MainBottomHBox.pack_start(MainBottomFrame, False, False, 0)
		
		MainBottom.add(MainBottomHBox)
		MainBottomFrame.add(MainBottomLabel)
		
		
		MainBottomLabel2 = gtk.Label("TODO")
		#MainBottomLabel2.show()
		
		MainBottomFrame2 = gtk.Frame("Server information")
		MainBottomHBox.pack_end(MainBottomFrame2, False, False)
		MainBottomFrame2.add(MainBottomLabel2)
		
		
		#Now we'll add a notification area icon (statusIcon)
		"""StatusIcon = gtk.StatusIcon()
		
		StatusMenu = gtk.Menu()        
		
		MenuItem =  gtk.MenuItem("Show/Hide ghellanzb")
		MenuItem.connect('activate', self.hide_window, False)
		StatusMenu.append(MenuItem)
		
		MenuItem = gtk.ImageMenuItem(gtk.STOCK_ADD)
		MenuItem.connect('activate', self.open_add_file_window, False)
		StatusMenu.append(MenuItem)
		
		MenuItem = gtk.ImageMenuItem(gtk.STOCK_QUIT)
		MenuItem.connect('activate', self.destroy, StatusIcon)
		StatusMenu.append(MenuItem)"""
		
		""" TODO : create an About Window """
		"""MenuItem = gtk.ImageMenuItem(gtk.STOCK_ABOUT)
		MenuItem.connect('activate', self.activate_icon)
		StatusMenu.append(MenuItem)"""
		
		"""StatusIcon.set_from_file('icon.png')
		StatusIcon.set_tooltip('ghellanzb')
		StatusIcon.connect('activate', self.activate_icon)
		StatusIcon.connect('popup-menu', self.popup_menu, StatusMenu)
		StatusIcon.set_visible(True)"""
		
		
		self.MainWindow.show_all()
		
	def popup_menu(self, widget, button, time, data = None):
		'''
		
		@param widget:
		@param button:
		@param time:
		@param data:
		'''
		if button == 3:
			if data:
				data.show_all()
				data.popup(None, None, None, 3, time)
		pass

	def activate_icon(widget, data = None):
		'''
		
		@param widget:
		@param data:
		'''
		msgBox = gtk.MessageDialog(parent = None, buttons = gtk.BUTTONS_OK, message_format = "StatusIcon test.")
		msgBox.run()
		msgBox.destroy()
		
	def hide_window(self, widget, void):
		'''
		
		@param widget:
		@param void:
		'''
		if self.window_show:
			self.MainWindow.hide()
			self.window_show = 0
		else:
			self.MainWindow.show()
			self.window_show = 1
		return True
		
	def create_add_file_window(self, filename):
		'''
		
		@param filename:
		'''
		"""
		Opens the Add File dialog. You can add a NZB file here. The argument this method takes
		is a filename, which will be set as the current file in the file selector
		"""
		
		self.AddFileWindow = gtk.Window()
		self.AddFileWindow.set_title("Add a NZB file")
		self.AddFileWindow.set_position(gtk.WIN_POS_CENTER)
		AddFileTable = gtk.Table(rows=4, columns=2, homogeneous=False)
		AddFileTable.show()
		self.AddFileWindow.add(AddFileTable)
		
		LabelSizeGroup = gtk.SizeGroup(gtk.SIZE_GROUP_BOTH)
		InputSizeGroup = gtk.SizeGroup(gtk.SIZE_GROUP_BOTH)
		
		FileLabel = gtk.Label("File: ")
		LabelSizeGroup.add_widget(FileLabel)
		FileLabel.show()
		AddFileTable.attach(FileLabel,0 ,1, 0, 1,xoptions=gtk.EXPAND, yoptions=gtk.SHRINK, ypadding=10)
		TitleLabel = gtk.Label("Title: ")
		LabelSizeGroup.add_widget(TitleLabel)
		TitleLabel.show()
		AddFileTable.attach(TitleLabel,0 ,1, 1, 2,xoptions=gtk.EXPAND, yoptions=gtk.SHRINK, ypadding=10)
		CategoryLabel = gtk.Label("Category: ")
		LabelSizeGroup.add_widget(CategoryLabel)
		CategoryLabel.show()
		AddFileTable.attach(CategoryLabel,0 ,1, 2, 3,xoptions=gtk.EXPAND, yoptions=gtk.SHRINK, ypadding=10)
		
		self.FileName = gtk.FileChooserButton("Choose a file")
		Filter = gtk.FileFilter()
		Filter.add_pattern("*.nzb")
		Filter.add_pattern("*.NZB")

		self.FileName.set_filter(Filter)
		InputSizeGroup.add_widget(self.FileName)
		if filename:
			self.FileName.set_filename(filename)
		self.FileName.connect_object("selection-changed", self.change_title, None)
		self.FileName.show()
		AddFileTable.attach(self.FileName,1 ,2, 0, 1,xoptions=gtk.EXPAND, yoptions=gtk.SHRINK, xpadding=10, ypadding=10)
		
		self.Title = gtk.Entry()
		InputSizeGroup.add_widget(self.Title)
		self.Title.show()
		AddFileTable.attach(self.Title,1 ,2, 1, 2,xoptions=gtk.EXPAND, yoptions=gtk.SHRINK, xpadding=10, ypadding=10)
		
		self.Category = gtk.combo_box_new_text()
		self.Category.append_text("Music")
		self.Category.append_text("DVD Movie")
		self.Category.append_text("XVID Movie")
		self.Category.append_text("TV Series")
		self.Category.append_text("HD Movie")
		self.Category.append_text("Game")
		self.Category.append_text("Software")
		self.Category.append_text("Other")
		self.Category.set_active(7)
		InputSizeGroup.add_widget(self.Category)
		self.Category.show()
		AddFileTable.attach(self.Category,1 ,2, 2, 3,xoptions=gtk.EXPAND, yoptions=gtk.SHRINK, xpadding=10, ypadding=10)
		
		#And now, some buttons!
		HButtonBox = gtk.HButtonBox()
		HButtonBox.set_layout(gtk.BUTTONBOX_END)
		InputSizeGroup.add_widget(HButtonBox)
		AddFileTable.attach(HButtonBox,1 ,2, 3, 4,xoptions=gtk.EXPAND, yoptions=gtk.SHRINK, xpadding=10, ypadding=15)
		HButtonBox.show()
		
		AddButton = gtk.Button(label="Add file",stock=gtk.STOCK_ADD)
		#InputSizeGroup.add_widget(AddButton)
		AddButton.show()
		AddButton.connect_object("clicked", self.add_file, None)
		HButtonBox.add(AddButton)
		#And a cancel button!
		CancelButton = gtk.Button(label="Restore",stock=gtk.STOCK_CANCEL)
		CancelButton.show()
		CancelButton.connect_object("clicked", self.hide, self.AddFileWindow)
		HButtonBox.add(CancelButton)
		
		self.AddFileWindow.show_all()
		
	def create_preferences_window(self):
		'''
		
		'''
		# FIXME:Problem with the preferences window in the General Tab, for the executables (unrar and par) the FileChooserButton does not want to display the options retreive form Hellanzb Preferences.
		# TODO: Add an option in the server preferences : CheckButton for the authentification, if uncheck both usernae nd password are "grey"
		# TODO:If in the hellanzb preferences no authentification, un check the previous CheckButton.
		# TODO:Add the possibility to create and remove servers
		# TODO:Add a CheckButton to enable or disable a server (this option is present in hellanzb.conf but the line is commented)
		# TODO: Add the other server options (bindTo, enabled, skipGroupCmd and fillservers)

		""" Retreive hellanzb preferences from hellanzb.conf """
		self.get_preferences()
		
		"""Creates the preferences dialog"""
		PreferencesWindow = gtk.Window()
		PreferencesWindow.show()
		PreferencesWindow.set_title("Preferences")
		
		"""PreferencesTable = gtk.Table(rows=6, columns=2, homogeneous=False)
		PreferencesTable.show()
		self.preferencesLabelSizeGroup = gtk.SizeGroup(gtk.SIZE_GROUP_BOTH)
		self.preferencesLabelSizeGroup2 = gtk.SizeGroup(gtk.SIZE_GROUP_BOTH)"""
		
		PreferencesVBox = gtk.VBox(False,10)
		PreferencesWindow.add(PreferencesVBox)
		
		PreferencesServerLabel = gtk.Label("Server")
		PreferencesAdvancedLabel = gtk.Label("Advanced")
		PreferencesNotebook = gtk.Notebook()
		#PreferencesNotebook.append_page(PreferencesServer, PreferencesServerLabel)
		PreferencesVBox.pack_start(PreferencesNotebook, True, True, 0)
		
		
		""" Create the advanced table """
		"""PreferencesTable3 = gtk.Table(rows=7, columns=2, homogeneous=False)"""
		#PreferencesNotebook.append_page(PreferencesAdvanced, PreferencesAdvancedLabel)
		
		'''
		""" Add the host label """
		HostLabel = gtk.Label("Host: ")
		self.preferencesLabelSizeGroup.add_widget(HostLabel)
		PreferencesTable.attach(HostLabel,0 ,1, 0, 1,xoptions=gtk.SHRINK, yoptions=gtk.SHRINK, ypadding=10)
		
		""" Add the username label """
		self.preferencesUsernameLabel = gtk.Label("Username: ")
		self.preferencesLabelSizeGroup.add_widget(self.preferencesUsernameLabel)
		self.preferencesUsernameLabel.show()
		PreferencesTable.attach(self.preferencesUsernameLabel,0 ,1, 1, 2,xoptions=gtk.SHRINK, yoptions=gtk.SHRINK, ypadding=10)
		
		""" Add the password label """
		self.preferencesPasswordLabel = gtk.Label("Password: ")
		self.preferencesLabelSizeGroup.add_widget(self.preferencesPasswordLabel)
		self.preferencesPasswordLabel.show()
		PreferencesTable.attach(self.preferencesPasswordLabel,0 ,1, 2, 3,xoptions=gtk.SHRINK, yoptions=gtk.SHRINK, ypadding=10)
		
		""" Add number of connections label """
		self.preferencesConnectionsLabel = gtk.Label("Number of connections: ")
		self.preferencesLabelSizeGroup.add_widget(self.preferencesConnectionsLabel)
		self.preferencesConnectionsLabel.show()
		PreferencesTable.attach(self.preferencesConnectionsLabel,0 ,1, 3, 4,xoptions=gtk.SHRINK, yoptions=gtk.SHRINK, ypadding=10)
		
		""" Add number of ssl label """
		self.preferencesSSLLabel = gtk.Label("Enable SSL: ")
		self.preferencesLabelSizeGroup.add_widget(self.preferencesSSLLabel)
		self.preferencesSSLLabel.show()
		PreferencesTable.attach(self.preferencesSSLLabel,0 ,1, 4, 5,xoptions=gtk.SHRINK, yoptions=gtk.SHRINK, ypadding=10)    
		'''
		"""
		Next section, the actual input!
		"""
					
		"""
		#First we create a sizegroup
		self.preferencesInputSizeGroup = gtk.SizeGroup(gtk.SIZE_GROUP_BOTH)
		self.preferencesInputSizeGroup2 = gtk.SizeGroup(gtk.SIZE_GROUP_BOTH)

		
		#Add the hosts input field
		self.preferencesHost = gtk.Entry()
		self.preferencesInputSizeGroup.add_widget(self.preferencesHost)
		self.preferencesHost.show()        
		PreferencesTable.attach(self.preferencesHost,1 ,2, 0, 1,xoptions=gtk.EXPAND, yoptions=gtk.SHRINK, ypadding=10)

		#Add the username input field
		self.preferencesUsername = gtk.Entry()
		self.preferencesInputSizeGroup.add_widget(self.preferencesUsername)
		self.preferencesUsername.show()
		PreferencesTable.attach(self.preferencesUsername,1 ,2, 1, 2,xoptions=gtk.EXPAND, yoptions=gtk.SHRINK, ypadding=10)
		
		#Add the password input field
		self.preferencesPassword = gtk.Entry()
		self.preferencesInputSizeGroup.add_widget(self.preferencesPassword)
		self.preferencesPassword.set_visibility(False)
		self.preferencesPassword.show()
		PreferencesTable.attach(self.preferencesPassword,1 ,2, 2, 3,xoptions=gtk.EXPAND, yoptions=gtk.SHRINK, ypadding=10)
		
		#Add the connections drop-down menu
		
		self.preferencesConnections = gtk.combo_box_new_text()
		self.preferencesInputSizeGroup.add_widget(self.preferencesConnections)
		self.preferencesConnections.show()
		for number in range(1,21):
			self.preferencesConnections.append_text(str(number))
		PreferencesTable.attach(self.preferencesConnections, 1, 2, 3, 4,xoptions=gtk.EXPAND, yoptions=gtk.SHRINK, ypadding=10)
		
		#Add the SSL checkbox
		
		self.preferencesSSL = gtk.CheckButton(label=None)
		self.preferencesSSL.show()
		PreferencesTable.attach(self.preferencesSSL,1 ,2, 4, 5,xoptions=gtk.EXPAND, yoptions=gtk.SHRINK, ypadding=10)
		"""
	
	
		
		
		"""
		
		"""
		
		#And now the general tab:
		
		PreferencesGeneralLabel = gtk.Label("General")
		PreferencesGeneral = gtk.VBox()
		PreferencesNotebook.append_page(PreferencesGeneral, PreferencesGeneralLabel)
		
		
		#Add the Download frame
		DownloadFrame = gtk.Frame("Downloads")
		PreferencesGeneral.pack_start(DownloadFrame, False, False, 5)
		DownloadDirHBox = gtk.HBox()
		DownloadFrame.add(DownloadDirHBox)
		DownloadDirLabel = gtk.Label("Download directory: ")
		DownloadDirHBox.pack_start(DownloadDirLabel, False, False, 2)
		self.DownloadDir = gtk.FileChooserButton("Choose the download directory")
		self.DownloadDir.set_action(gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER)
		DownloadDirHBox.pack_end(self.DownloadDir, False, False, 2)
		self.DownloadDir.set_current_folder(self.hella_preferences['DEST_DIR'])
		
		
		#Add the executables frame
		ExecutablesFrame = gtk.Frame("Executables")
		PreferencesGeneral.pack_start(ExecutablesFrame, False, False, 5)
		ExecutablesVBox = gtk.VBox()
		ExecutablesFrame.add(ExecutablesVBox)

		UnrarLocationHBox = gtk.HBox()
		ExecutablesVBox.pack_start(UnrarLocationHBox)
		UnrarLocationLabel = gtk.Label("unrar location: ")
		UnrarLocationHBox.pack_start(UnrarLocationLabel, False, False, 2)
		UnrarLocation = gtk.FileChooserButton("Choose a file")
		UnrarLocationHBox.pack_end(UnrarLocation, False, False, 2)
		self.UnrarLocationEntry = gtk.Entry()
		UnrarLocationHBox.pack_end(self.UnrarLocationEntry, False, False, 2)
		#UnrarLocation.set_current_folder(UnrarLocationEntry.get_text())
		self.UnrarLocationEntry.set_text(self.hella_preferences['UNRAR_CMD'])

		ParLocationHBox = gtk.HBox()
		ExecutablesVBox.pack_start(ParLocationHBox)
		ParLocationLabel = gtk.Label("par location: ")
		ParLocationHBox.pack_start(ParLocationLabel, False, False, 2)
		ParLocation = gtk.FileChooserButton("Choose a file")
		ParLocationHBox.pack_end(ParLocation, False, False, 2)
		self.ParLocationEntry = gtk.Entry()
		ParLocationHBox.pack_end(self.ParLocationEntry, False, False, 2)
		#ParLocation.set_current_folder(self.hella_preferences['PAR2_CMD'])
		self.ParLocationEntry.set_text(self.hella_preferences['PAR2_CMD'])

		SmartParFrame = gtk.Frame("Par repair")
		PreferencesGeneral.pack_start(SmartParFrame, False, False, 5)
		SmartParHBox = gtk.HBox()
		SmartParFrame.add(SmartParHBox)
		SmartParLabel = gtk.Label("Enable SmartPar: ")
		SmartParHBox.pack_start(SmartParLabel, False, False, 2)
		self.SmartParButton = gtk.CheckButton(label=None)
		SmartParHBox.pack_end(self.SmartParButton, False, False, 2)
		self.SmartParButton.set_active(self.hella_preferences['SMART_PAR'])
		
		#Add the Notify frame
		NotifyFrame = gtk.Frame("Libnotify")
		PreferencesGeneral.pack_start(NotifyFrame, False, False, 5)
		NotifyHBox = gtk.HBox()
		NotifyFrame.add(NotifyHBox)
		NotifyLabel = gtk.Label("Enable notifications: ")
		NotifyHBox.pack_start(NotifyLabel, False, False, 2)
		self.NotifyButton = gtk.CheckButton()
		NotifyHBox.pack_end(self.NotifyButton, False, False, 2)
		self.NotifyButton.set_active(self.hella_preferences['LIBNOTIFY_NOTIFY'])
		
		"""#Add the Minimized frame
		self.MinimizedFrame = gtk.Frame("Start-up")
		self.preferencesGeneral.pack_start(self.MinimizedFrame, False, False, 5)
		self.preferencesMinimizedHBox = gtk.HBox()
		self.MinimizedFrame.add(self.preferencesMinimizedHBox)
		self.preferencesMinimizedLabel = gtk.Label("Start in tray: ")
		self.preferencesMinimizedHBox.pack_start(self.preferencesMinimizedLabel, False, False, 2)
		self.preferencesMinimized = gtk.CheckButton(label=None)
		self.preferencesMinimizedHBox.pack_end(self.preferencesMinimized, False, False, 2)"""
		
		#Add the Throttle frame
		MaxRateFrame = gtk.Frame("Maximun rate")
		PreferencesGeneral.pack_start(MaxRateFrame, False, False, 5)
		MaxRateHBox = gtk.HBox()
		MaxRateFrame.add(MaxRateHBox)
		MaxRateLabel = gtk.Label("Maximum speed (kb/s): ")
		MaxRateHBox.pack_start(MaxRateLabel, False, False, 2)
		self.MaxRate = gtk.Entry()
		self.MaxRate.set_size_request(40, 20)
		self.MaxRate.set_alignment(1)
		MaxRateHBox.pack_end(self.MaxRate, False, False, 2)
		self.MaxRate.set_text(str(self.hella_preferences['MAX_RATE']))
		
		PreferencesServersLabel = gtk.Label("Server")
		PreferencesServers = gtk.VBox()
		PreferencesNotebook.append_page(PreferencesServers, PreferencesServersLabel)
		
		IDHBox = gtk.HBox()
		PreferencesServers.pack_start(IDHBox, False, False, 5)
		IDLabel = gtk.Label("Servers.")
		IDHBox.pack_start(IDLabel, False, False, 2)
		ID = gtk.combo_box_new_text()
		for id in self.hella_preferences['SERVERS']:
			ID.append_text(id)
		ID.set_active(0)
		self.get_selected_server(ID)
		ID.connect('changed', self.get_selected_server, ID)
		IDHBox.pack_end(ID, False, False, 2)
		
		ServerFrame = gtk.Frame('Server : ' + self.hella_preferences['SERVERS'][self.selected_server]['id'])
		PreferencesServers.pack_start(ServerFrame, False, False, 5)
		ServerVBox = gtk.VBox()
		ServerFrame.add(ServerVBox)
				
		ServerEnableHBox = gtk.HBox()
		ServerVBox.add(ServerEnableHBox)
		ServerEnableLabel = gtk.Label('Enable Server :')
		ServerEnableHBox.pack_start(ServerEnableLabel, False, False, 2)
		self.ServerEnable = gtk.CheckButton()
		self.ServerEnable.set_active(self.hella_preferences['SERVERS'][self.selected_server]['enabled'])
		ServerEnableHBox.pack_end(self.ServerEnable, False, False, 2)
				
		ServerNameHBox = gtk.HBox()
		ServerVBox.add(ServerNameHBox)
		ServerNameLabel = gtk.Label('Name :')
		ServerNameHBox.pack_start(ServerNameLabel, False, False, 2)
		self.ServerName = gtk.Entry()
		self.ServerName.set_text(self.hella_preferences['SERVERS'][self.selected_server]['id'])
		ServerNameHBox.pack_end(self.ServerName, False, False, 2)
		
		ServerHostHBox = gtk.HBox()
		ServerVBox.add(ServerHostHBox)
		ServerHostLabel = gtk.Label('Host (IP Address:Port) :')
		ServerHostHBox.pack_start(ServerHostLabel, False, False, 2)
		self.ServerHost = gtk.Entry()
		self.ServerHost.set_text(self.hella_preferences['SERVERS'][self.selected_server]['hosts'][0])
		ServerHostHBox.pack_end(self.ServerHost, False, False, 2)
		
		ServerUsernameHBox = gtk.HBox()
		ServerVBox.add(ServerUsernameHBox)
		ServerUsernameLabel = gtk.Label('Username :')
		ServerUsernameHBox.pack_start(ServerUsernameLabel, False, False, 2)
		self.ServerUsername = gtk.Entry()
		self.ServerUsername.set_text(str(self.hella_preferences['SERVERS'][self.selected_server]['username']))
		ServerUsernameHBox.pack_end(self.ServerUsername, False, False, 2)
		
		ServerPasswordHBox = gtk.HBox()
		ServerVBox.add(ServerPasswordHBox)
		ServerPasswordLabel = gtk.Label('Password :')
		ServerPasswordHBox.pack_start(ServerPasswordLabel, False, False, 2)
		self.ServerPassword = gtk.Entry()
		self.ServerPassword.set_text(str(self.hella_preferences['SERVERS'][self.selected_server]['password']))
		ServerPasswordHBox.pack_end(self.ServerPassword, False, False, 2)
	
		ServerConnectionsHBox = gtk.HBox()
		ServerVBox.add(ServerConnectionsHBox)
		ServerConnectionsLabel = gtk.Label('Connections :')
		ServerConnectionsHBox.pack_start(ServerConnectionsLabel, False, False, 2)
		self.ServerConnections = gtk.combo_box_new_text()
		for i in range(1, 9):
			self.ServerConnections.append_text(str(i))
		self.ServerConnections.set_active(int(self.hella_preferences['SERVERS'][self.selected_server]['connections'] - 1))
		self.ServerConnections.connect('changed', self.get_connections, self.ServerConnections)
		ServerConnectionsHBox.pack_end(self.ServerConnections, False, False, 2)
		
		ServerAntiIdleHBox = gtk.HBox()
		ServerVBox.add(ServerAntiIdleHBox)
		ServerAntiIdleLabel = gtk.Label('AntiIdle (min) :')
		ServerAntiIdleHBox.pack_start(ServerAntiIdleLabel, False, False, 2)
		self.ServerAntiIdle = gtk.Entry()
		self.ServerAntiIdle.set_alignment(1)
		self.ServerAntiIdle.set_size_request(50, 20)
		self.ServerAntiIdle.set_text(str(self.hella_preferences['SERVERS'][self.selected_server]['antiIdle']))
		ServerAntiIdleHBox.pack_end(self.ServerAntiIdle, False, False, 2)
		
		ServerSkipGroupCmdHBox = gtk.HBox()
		ServerVBox.add(ServerSkipGroupCmdHBox)
		ServerSkipGroupCmdLabel = gtk.Label('Skip Group Command :')
		ServerSkipGroupCmdHBox.pack_start(ServerSkipGroupCmdLabel, False, False, 2)
		self.ServerSkipGroupCmd = gtk.CheckButton()
		self.ServerSkipGroupCmd.set_active(self.hella_preferences['SERVERS'][self.selected_server]['skipGroupCmd'])
		ServerSkipGroupCmdHBox.pack_end(self.ServerSkipGroupCmd, False, False, 2)
				
		ServerSSLHBox = gtk.HBox()
		ServerVBox.add(ServerSSLHBox)
		ServerSSLLabel = gtk.Label('SSL :')
		ServerSSLHBox.pack_start(ServerSSLLabel, False, False, 2)
		self.ServerSSL = gtk.CheckButton()
		self.ServerSSL.set_active(self.hella_preferences['SERVERS'][self.selected_server]['ssl'])
		ServerSSLHBox.pack_end(self.ServerSSL, False, False, 2)
		
		ButtonHBox = gtk.HButtonBox()
		ButtonHBox.set_layout(gtk.BUTTONBOX_END)
		PreferencesVBox.pack_end(ButtonHBox, True, True, 0)

		SaveButton = gtk.Button(label="Safe Preferences",stock=gtk.STOCK_SAVE)
		SaveButton.connect_object("clicked", self.save_preferences, PreferencesWindow)
		ButtonHBox.add(SaveButton)
		
		CancelButton = gtk.Button(label="Restore",stock=gtk.STOCK_CANCEL)
		CancelButton.connect_object("clicked", self.hide, PreferencesWindow)
		ButtonHBox.add(CancelButton)
		
		PreferencesWindow.show_all()

	def save_preferences(self, window):
		'''
		
		@param window:
		'''
		if self.SmartParButton.get_active() != self.hella_preferences['SMART_PAR']:
			print 'Configuration has changed for the Smart Par : %s' % self.SmartParButton.get_active()
			#setattr(Hellanzb, 'SMART_PAR', self.SmartParButton.get_active())
			path = self.hella_status['config_file']
			(filepath, filename) = os.path.split(path)
			pref_path = os.path.join(filepath, filename)
			for line in open(pref_path, 'r+'):
				if line.startswith('Hellanzb.SMART_PAR'):
					print"It's the line I need to modify"
					print line
					new_line = 'Hellanzb.SMART_PAR = ' + str(self.SmartParButton.get_active())
					line.replace('False', str(self.SmartParButton.get_active()))
					print line
					
			
		self.hide(window)
		
	def hide (self, window):
		'''
		
		@param window:
		'''
		print "let's hide"
		window.hide()
		
	def add_column_to_treeview(self, title, columnID):
		'''
		
		@param title:
		@param columnID:
		'''
		column = gtk.TreeViewColumn(title, gtk.CellRendererText(), text=columnID)
		column.set_resizable(True)
		column.set_expand(True)
		self.QueueTree.append_column(column)
	
	def add_progressbar_to_treeview(self, title, columnID, progress):
		'''
		
		@param title:
		@param columnID:
		@param progress:
		'''
		column = gtk.TreeViewColumn(title, gtk.CellRendererProgress(), text=columnID, value=progress)
		column.set_resizable(False)
		column.set_expand(False)
		column.set_sizing(gtk.TREE_VIEW_COLUMN_FIXED)
		column.set_fixed_width(200)
		self.QueueTree.append_column(column)
		
	def update_queue(self):
		'''
		
		'''
		"""  Reload the hellanzb status in order to update the display """
		self.connect()
		self.get_currently_downloading()
		self.get_queued()
		self.get_currently_processing()
		iter = self.current_queue.get_iter_first()
										
		if self.update :
			print 'something changed...'
			self.current_queue.clear()
			if self.downloading != {}:
				if self.downloading['is_par_recovery']:
					self.current_queue.append([self.downloading['nzbName'], self.downloading['total_mb'], self.downloading['time'], self.downloading['percent_complete'], str(self.downloading['percent_complete']) + '%', self.downloading['id']])
				else :
					if self.pause:
						print "tiens c'est en pause"
						self.current_queue.append([self.downloading['nzbName'], self.downloading['total_mb'], self.downloading['time'], self.downloading['percent_complete'], 'Paused at : ' + str(self.downloading['percent_complete']) + "%", self.downloading['id']])
					else :
						self.current_queue.append([self.downloading['nzbName'], self.downloading['total_mb'], self.downloading['time'], self.downloading['percent_complete'], str(self.downloading['percent_complete']) + "%", self.downloading['id']])
				
				if self.processing != []:
					for file in self.processing:
						if file['is_par_recovery']:
							self.current_queue.append([file[0], file[1], file[2],  file[3], 'repairing and extracting', file[5]])
						else :
							self.current_queue.append([file[0], file[1], file[2],  file[3], file[4], file[5]])
				if self.queued != []:
					for file in self.queued:
						self.current_queue.append([file[0], file[1], file[2], file[3], file[4], file[5]])
				if self.done !=[]:
					for file in self.done:
						self.current_queue.append([file[0], file[1],  'done', 100, file[5]])
			self.update = 0
			print 'iter is %s' % iter
		if iter:
			if self.pause:
				self.current_queue.set(iter, 4, "Paused at: " + str(self.downloading['percent_complete']) + "%")
			else :
				self.current_queue.set(iter, 4, str(self.downloading['percent_complete']) + "%")

	
	def delete_from_queue(self,button):
		'''
		
		@param button:
		'''
		selection = self.QueueTree.get_selection()
		model, selection_iter = selection.get_selected()
		if (selection_iter):
			selected_id = model.get_value(selection_iter, 5)
			hella_status = self.get_status()
			if selected_id == hella_status["currently_downloading"][0]["id"]:
				self.hella_server.cancel()
			else:
				self.hella_server.dequeue(selected_id)
				self.current_queue.remove(selection_iter)
			print 'selected_id to be removed  is %s' % selected_id
		self.update_queue()
		
	def change_title(self, widget):
		'''
		
		@param widget:
		'''
		if self.FileName.get_filename() != None:
			self.tempname = self.FileName.get_filename()[:-4].split("/")[-1].replace("."," ").replace("_"," ")
			self.Title.set_text(self.tempname)
			
	def add_file(self, widget):
		'''
		
		@param widget:
		'''
		if self.FileName.get_filename() != None:
			self.file = self.FileName.get_filename()
			self.temp = self.Category.get_active()
			if self.temp == 0:
				self.category = "Music"
			elif self.temp == 1:
				self.category = "DVD Movie"
			elif self.temp == 2:
				self.category = "XVID Movie"
			elif self.temp == 3:
				self.category = "TV Series"
			elif self.temp == 4:
				self.category = "HD Movie"
			elif self.temp == 5:
				self.category = "Game"
			elif self.temp == 6:
				self.category = "Software"
			elif self.temp == 7:
				self.category = "Other"
			self.title = self.Title.get_text()
			#print 'self.file:%s - self.category:%s - self.title:%s' % (self.file, self.category, self.title)
			queue_dir = self.hella_preferences['QUEUE_DIR']
			print 'queue_dir is %s' % queue_dir
			move(self.file, queue_dir)
			self.refresh(self.file, self.title)
			
			self.AddFileWindow.hide()
			sleep(3)
			self.update_queue()
		
	"""def openWindowHider(self, widget):
		self.AddFileWindow.hide()"""
	
	"""def visible(self, model, iter, data):
		print 'model.get_value(iter,2) in data[0] is %s' % model.get_value(iter,2) in data[0]
		return model.get_value(iter,2) in data[0]"""
	
	def refresh(self, widget, data = None):
		'''
		
		@param widget:
		@param data:
		'''
		self.update_queue()
	
	def move_in_queue(self, up):
		'''
		
		@param up:
		'''
		#FIXME: 'server.force(id)' never called because even if they are equals, the method does not agree. (move_in_queue)
		selection = self.QueueTree.get_selection()
		model, selection_iter = selection.get_selected()
		if self.current_queue.get_value(selection_iter, 5) == self.hella_status["currently_downloading"][0]["id"]:
			if not up:
				if self.queued != []:
					id = self.current_queue.get_value(self.current_queue.get_iter(1), 5)
					self.hella_server.force(id)
					print "forced", id, "to begin"
		elif (selection_iter):
			id = self.current_queue.get_value(selection_iter, 5)
			print 'now id is (%s)' % id
			print "and self.hella_status['queued'][0]['id'] is (%s)" % self.hella_status['queued'][0]['id']
			if up:
				print 'GET UP'
				if  id ==  self.hella_status['queued'][0]['id'] :
					print "good they are the same"
					self.hella_server.force(id)
					print 'forced',id,'to begin..'
				else:
					self.hella_server.up(id)
					print 'moved',id,'up'
			else:
				self.hella_server.down(id)
				print 'moved',id,'down'
		self.update_queue()
		
	def pause_download(self, widget):
		'''
		
		@param widget:
		'''
		if self.pause:
			self.pause = 0
			os.system('hellanzb.py' + " continue")
			#self.hella_server.continue()
			print "Continued downloading"
		else:
			self.pause = 1
			self.hella_server.pause()
			print "Paused downloading"
		print 'on recharge la queue'
		self.update_queue()

	def destroy(self,  widget, data=None):
		'''
		
		@param widget:
		@param data:
		'''
		print "destroy signal occurred"
		self.runner = 0
		gtk.main_quit()
		
	def open_add_file_window(self, widget, data = None):
		'''
		
		@param widget:
		@param data:
		'''
		print "let's diplay the Add File window"
		self.create_add_file_window(False)
		
	def open_preferences_window(self, widget, data = None):
		'''
		
		@param widget:
		@param data:
		'''
		print "let's diplay the Preferences window"
		self.create_preferences_window()
		
	def connect (self):
		'''
		Connect to the hellanzb daemon to retreive its status
		'''
		"""
		
		"""
		# Ecriture en dure des valeurs qui seront plus tard lu dans le fichier hellanzb.conf
		server = 'localhost'
		port = '8760'
		server_username = 'hellanzb'
		server_password = 'changeme'
		
		# Definition de l'url d'acces
		self.hella_server = ServerProxy('http://' + server_username + ':' + server_password + '@' + server + ':' + port)
		
		# Recuperation du status en cours
		self.hella_status = self.hella_server.status()
		print 'self.hella_status is %s' % self.hella_status
		
	def get_status(self):
		'''
		
		'''
		""" Retreive the current status of hellanzb """
		self.connect()
		return self.hella_status
	
	"""def cancel(self):
		self.connect()
		self.hella_server.cancel()
		
	def dequeue(self, selected_id):
		self.connect()
		self.hella_server.dequeue(selected_id)"""
		
		
		
	def get_currently_downloading(self):
		'''
		
		'''
		
		# Test if something is in 'currently_downloading'
		try :  self.hella_downloading = self.hella_status['currently_downloading'][0]
		except : return
		#print "Let's see what I am currently downloading"
		#Check if there was some modifications since the last update_queue
		if self.hella_status['currently_downloading'] !=  self.buffer_downloading:
			print 'there are some changes in the currently downloading ...'
			
			self.downloading['nzbName'] = self.hella_downloading['nzbName']
			self.downloading['total_mb'] = self.hella_downloading['total_mb']
		
			try: self.downloading['time'] = self.hella_downloading['time']
			except: self.downloading['time'] = ' '
		
			try: self.downloading['maxrate'] = self.hella_downloading['maxrate']
			except: self.downloading['maxrate'] = 0
		
			try:
				self.downloading['percent_complete'] = self.hella_status['percent_complete']
				if self.downloading['percent_complete'] > 100 :
					self.downloading['percent_complete'] = 100
			except:
				self.downloading['percent_complete'] = 0
				print "self.hella_status['percent_complete'] is %s" % self.hella_status['percent_complete']
		
			try : self.downloading['id'] = self.hella_downloading['id']
			except: self.downloading['id'] = None
			
			try : self.downloading['is_par_recovery'] = self.hella_downloading['is_par_recovery']
			except: self.downloading['is_par_recovery'] = None
			
			#Fill the buffer_downloading with the actual currently_downloading
			self.buffer_downloading = self.hella_status['currently_downloading']
			#print 'self.hella_downloading is %s' % self.hella_downloading
						
			"""#Fill the ListStore with the values retreived
			self.current_queue.append([NzbName, Total_MB, Time, MaxRate, Percent_Complete, id])"""
			self.update = 1

	
	def get_queued(self):
		'''
		
		'''
		""" retreive all files beeing queued and place them in the ListStore"""
		
		try : self.hella_queued = self.hella_status['queued'][0]
		except : return
		#print "what will I download next ??"
		if  self.hella_status['queued'] != self.buffer_queued :
			print "something changed in the queue ..."
			i = 0
			self.queued = []
			for nzb_file in self.hella_status['queued']:
				NzbName = self.hella_status['queued'][i]['nzbName']
				print 'nzbName is %s' % NzbName
				Total_MB = self.hella_status['queued'][i]['total_mb']
				id = self.hella_status['queued'][i]['id']
			
				#Fill the buffer_queued with the actual values of  queued
				self.buffer_queued = self.hella_status['queued']
				self.queued.append([NzbName, Total_MB, None, 0, 'Queued', id])
			
				"""self.current_queue.append([NzbName, Total_MB, None, None, 'Queued', id])
				#print '(%s, %s, %s)' %(NzbName, Total_MB, id)"""
				i = i + 1
				self.update = 1
			
	def get_currently_processing(self):
		'''
		
		'''
		
		try : self.hella_processing = self.hella_status['currently_processing']
		except : return
		
		if self.hella_status['currently_processing'] != self.buffer_processing :
			for file in self.hella_status['currently_processing']:
				NzbName = file['nzbName']
				Total_MB = file['total_mb']
				id = file['id']
				is_par_recovery = file['is_par_recovery']
				self.processing.append([NzbName, Total_MB, None, 100, 'processing', id])
				
		
				self.hella_processing = self.hella_status['currently_processing']
				self.update = 1
	
	def get_preferences (self):
		'''
		
		'''
		
		#self.connect()
		# Recuperation du chemin du fichier hellanzb.conf
		path = self.hella_status['config_file']
		(filepath, filename) = os.path.split(path)
		pref_path = os.path.join(filepath, filename)
		#pref_path = 'D:\Personnel\dev\workspace\hellanzb-0.13\etc\hellanzb.conf.sample'
		
		execfile(pref_path)
		
		self.hella_preferences = {}
		self.hella_preferences['SERVERS'] = {}
		
		try : self.hella_preferences['LOG_FILE'] = getattr(Hellanzb, 'LOG_FILE')
		except : pass
		try : self.hella_preferences['DEBUG_MODE'] = getattr(Hellanzb, 'DEBUG_MODE')
		except : pass
		try : self.hella_preferences['LOG_FILE_MAX_BYTES'] = getattr(Hellanzb, 'LOG_FILE_MAX_BYTES')
		except : pass
		try : self.hella_preferences['LOG_FILE_BACKUP_COUNT'] = getattr(Hellanzb, 'LOG_FILE_BACKUP_COUNT')
		except : pass
		for id in getattr(Hellanzb, 'SERVERS'):
			self.hella_preferences['SERVERS'][id] = {}
			d_label = {}
			for label in getattr(Hellanzb, 'SERVERS')[id]:
				value = getattr(Hellanzb, 'SERVERS')[id][label]
				d_label[label] = value
				self.hella_preferences['SERVERS'][id] = d_label
		
		try : self.hella_preferences['MAX_RATE'] = getattr(Hellanzb, 'MAX_RATE')
		except : pass
		try : self.hella_preferences['PREFIX_DIR'] = getattr(Hellanzb, 'PREFIX_DIR')
		except : pass
		try : self.hella_preferences['QUEUE_DIR'] = getattr(Hellanzb, 'QUEUE_DIR')
		except : pass
		try : self.hella_preferences['DEST_DIR'] = getattr(Hellanzb, 'DEST_DIR')
		except : pass
		try : self.hella_preferences['CURRENT_DIR'] = getattr(Hellanzb, 'CURRENT_DIR')
		except : pass
		try : self.hella_preferences['WORKING_DIR'] = getattr(Hellanzb, 'WORKING_DIR')
		except : pass
		try : self.hella_preferences['POSTPONED_DIR'] = getattr(Hellanzb, 'POSTPONED_DIR')
		except : pass
		try : self.hella_preferences['PROCESSING_DIR'] = getattr(Hellanzb, 'PROCESSING_DIR')
		except : pass
		try : self.hella_preferences['TEMP_DIR'] = getattr(Hellanzb, 'TEMP_DIR')
		except : pass
		"""try : self.hella_preferences['STATE_XML_DIR'] = getattr(Hellanzb, 'STATE_XML_DIR')
		except : pass
		try : self.hella_preferences['PROCESSED_SUBDIR'] = getattr(Hellanzb, 'PROCESSED_SUBDIR')
		except : pass
		try : self.hella_preferences['DELETE_PROCESSED'] = getattr(Hellanzb, 'DELETE_PROCESSED')
		except : pass"""
		""" try : self.hella_preferences['CACHE_LIMIT'] = getattr(Hellanzb, 'CACHE_LIMIT')
		except : pass"""
		try : self.hella_preferences['CATEGORIZE_DEST'] = getattr(Hellanzb, 'CATEGORIZE_DEST')
		except : pass
		try : self.hella_preferences['SMART_PAR'] = getattr(Hellanzb, 'SMART_PAR')
		except : pass
		try : self.hella_preferences['UNRAR_CMD'] = getattr(Hellanzb, 'UNRAR_CMD')
		except : pass
		try : self.hella_preferences['PAR2_CMD'] = getattr(Hellanzb, 'PAR2_CMD')
		except : pass
		try : self.hella_preferences['SKIP_UNRAR'] = getattr(Hellanzb, 'SKIP_UNRAR')
		except : pass
		#try : self.hella_preferences['MACBINCONV_CMD'] = getattr(Hellanzb, 'MACBINCONV_CMD')
		#except : pass
		#try : self.hella_preferences['UMASK'] = getattr(Hellanzb, 'UMASK')
		#except : pass
		"""try : self.hella_preferences['MAX_DECOMPRESSION_THREADS'] = getattr(Hellanzb, 'MAX_DECOMPRESSION_THREADS')
		except : pass"""
		try : self.hella_preferences['XMLRPC_SERVER'] = getattr(Hellanzb, 'XMLRPC_SERVER')
		except : pass
		try : self.hella_preferences['XMLRPC_PORT'] = getattr(Hellanzb, 'XMLRPC_PORT')
		except : pass
		try : self.hella_preferences['XMLRPC_PASSWORD'] = getattr(Hellanzb, 'XMLRPC_PASSWORD')
		except : pass
		"""try : self.hella_preferences['NEWZBIN_USERNAME'] = getattr(Hellanzb, 'NEWZBIN_USERNAME')
		except : pass
		try : self.hella_preferences['NEWZBIN_PASSWORD'] = getattr(Hellanzb, 'NEWZBIN_PASSWORD')
		except : pass"""
		try : self.hella_preferences['LIBNOTIFY_NOTIFY'] = getattr(Hellanzb, 'LIBNOTIFY_NOTIFY')
		except : pass
		
		#
		print 'self.hella_preferences is %s' % self.hella_preferences
		
	def get_selected_server(self, combobox):
		'''
		
		@param combobox:
		'''
		model = combobox.get_model()
		index = combobox.get_active()
		if index:
			self.selected_server = model[index][0]
			print 'index'
			print 'self.selected_server is %s' % self.selected_server
		else:
			self.selected_server = model[0][0]
			print 'no index'
			print 'self.selected_server is %s' % self.selected_server
			
	def get_connections(self, combobox, data = None):
		'''
		
		@param combobox:
		@param data:
		'''
		model = combobox.get_model()
		index = combobox.get_active()
		if index:
			self.selected_connections = int(model[index][0])
			print 'index'
			print 'self.selected_connections is %s' % self.selected_connections
		else:
			self.selected_connections = int(self.hella_preferences['SERVERS'][self.selected_server]['connections'] + 1)
			print 'no index'
			print 'self.selected_connections is %s' % self.selected_connections
			
	def extract_server_values(self):
		'''
		
		'''
		
		for id in self.hella_preferences['SERVERS']:
			server_host = self.hella_preferences['SERVERS'][id]['hosts'][0]
			server_username = self.hella_preferences['SERVERS'][id]['username']
			server_password = self.hella_preferences['SERVERS'][id]['password']
			server_connections = self.hella_preferences['SERVERS'][id]['connections']
			server_antidle = self.hella_preferences['SERVERS'][id]['antiIdle']
			server_ssl = self.hella_preferences['SERVERS'][id]['ssl']
			
		
		"""for line in self.hella_preferences["Server"]:
			if line[0] == "hosts":
				server_host = line[2].strip("[").strip("]").strip()[1:][:-1]
			elif line[0] == "username":
				server_username = line[2].strip("'")
			elif line[0] == "password":
				server_password = line[2].strip("'")
			elif line[0] == "connections":
				server_connections = line[2]
			elif line[0] == "antiIdle":
				server_anti_idle = line[2]
			elif line[0] == "ssl":
				server_ssl = line[2][:-1]"""
		"""if self.hella_preferences["Hellanzb.MAX_RATE"][0]:
			throttle = self.hella_preferences["Hellanzb.MAX_RATE"][1]
		else: 
			throttle = '0'"""
		dest_dir = self.hella_preferences["DEST_DIR"][1].strip("'")
		server_tab_pref = [server_host, server_username, server_password, server_connections, server_antidle, server_ssl, dest_dir]
		
		return server_tab_pref
			
	def extract_general_values(self,):
		'''
		
		'''
		"""if self.hella_preferences['Hellanzb.LIBNOTIFY_NOTIFY'][1] == "True":
			self.preferencesNotify.set_active(True)
		else:
			self.preferencesNotify.set_active(False)"""
			
		"""if self.hella_preferences["Hellanzb.SMART_PAR"][1] == "True":
			self.preferencesPar.set_active(True)
		else:
			self.preferencesPar.set_active(False)"""
		par2_cmd = self.hella_preferences["PAR2_CMD"][1]
		unrar_cmd = self.hella_preferences["UNRAR_CMD"][1]

		#self.preferencesDownloadDir.set_current_folder(self.tempDownloadDir)
		general_tab_pref = [par2_cmd, unrar_cmd]
		return general_tab_pref
	



if __name__ == "__main__":
	print "let's roll"
	soft = ghellanzb()
	soft.start()
	gtk.main()
