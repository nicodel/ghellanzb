name = "gHellanzb Applet"
version = "0.1"
image_dir = "/usr/share/pixmaps"