#!/usr/bin/env python

# 
# gHellanzb Applet
#

from distutils.core import setup
import gHellanzb

# Put this here, so we can overwrite it in build.py
version = gHellanzb.version
name = gHellanzb.name

def runSetup():
    options = dict(
        name = name,
        version = version,
        author = 'Nicolas Delebecque',
        author_email = '<nicolas.delebecque@gmail.com>',
        url = 'http://nicoworkspace.free.fr/?q=ghellanzb-downloads',
        license = 'GNU/GPL',
        platforms = [ 'unix' ],
        description = 'gnome applet monitoring hellanzb',
        long_description = ("gHellanzb is a small gnome applet monitoring hellanzb"),

        packages = [ 'gHellanzb'],
        scripts = [ 'gHellanzb/gHellanzb_Applet.py' ],
        data_files = [ ( 'lib/bonobo/servers', [ 'servers/GNOME_gHellanzbApplet.server' ] ),
                       ( 'share/doc/gHellanzb', [ 'CHANGELOG', 'CREDITS', 'README' , 'PKG-INFO' ] ) ],
        )

    setup(**options)

if __name__ == '__main__':
    runSetup()
