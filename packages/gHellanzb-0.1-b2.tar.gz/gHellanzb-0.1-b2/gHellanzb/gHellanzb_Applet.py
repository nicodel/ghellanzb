#!/usr/bin/env python

import pygtk, gtk, gnomeapplet, gobject, sys, gnome, pango
pygtk.require('2.0')

"""we import the required method to access hellanzb server"""
from xmlrpclib import ServerProxy

import gHellanzb

class ghellanzb_applet:
    def __init__(self, applet, iid):
        
        """we define some useful variables for ghellanzb_applet"""
        self.hella_status = ''
        self.status = ''
        self.info_label_data = ''
        self.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
        self.created_window = 0
        
        """we initiate the gnome application and set up internal variables"""
        gnome.init(gHellanzb.name, gHellanzb.version)
        
        """we get the hellanzb status dic"""
        #self.hella_status = self.get_status_from_server()
        self.get_status_from_server()
        """we extract from the hellanzb status dic the actual status"""
        #self.status = self.extract_status()
        self.extract_status()
        
        """we define the applet"""
        self.applet = applet
        self.applet.connect('destroy', self.cleanup, None)
        """we create the toolbar hbox that will receive labels"""
        toolbar_hbox = gtk.HBox(False, 0)
        toolbar_event_box = gtk.EventBox()
        toolbar_event_box.add(toolbar_hbox)
        toolbar_event_box.connect('button-press-event', self.button_press)
        """we create the toolbar applet label"""
        toolbar_label = gtk.Label('hellanzb : ')       
        """we create the toolbar applet status label"""
        self.toolbar_status = gtk.Label(self.status)
        """we add both labels to the toolbar box"""
        toolbar_hbox.add(toolbar_label)
        toolbar_hbox.add(self.toolbar_status)
        """we add the toolbar box to the applet"""
        self.applet.add(toolbar_event_box)
        
                
        self.applet.show_all()
        
        """we check the status of hellanzb every 5 seconds"""
        i = gobject.timeout_add(5000, self.update_status, self.applet)
        #print 'i is %s' % i        #DEBUG
    
    def cleanup(self, event, widget):
        del self.applet
    
    def update_status(self, event):
        #print "let's update the status"        #DEBUG
        self.get_status_from_server()
        self.extract_status()
        #print 'self.status is %s' % self.status        #DEBUG
        self.toolbar_status.set_text(self.status)
        return True
    
    def button_press(self, widget, event):
        #print 'button is %s' % event.button        #DEBUG
        if event.type == gtk.gdk.BUTTON_PRESS and event.button == 3:
            pass
            #print "let's display the menu"        #DEBUG
        if event.type == gtk.gdk.BUTTON_PRESS and event.button == 1:
            #print "let's display the status"        #DEBUG
            if not self.window.props.visible:
                self.applet.set_state(gtk.STATE_SELECTED)
                #"""we extract the version and config file path from the hella_status"""
                #self.extract_version_config_file()
                #"""we extract the currently_downloading if there is something to download"""
                #self.extract_currently_downloading()
                """if self.created_window == 0:
                    self.create_details_window()"""
                self.create_details_window()
                self.position_window()
                self.window.stick()
                self.window.show_all()
                self.window.grab_focus()
            else:
                self.applet.set_state(gtk.STATE_NORMAL)
                self.window.destroy()
            
    def create_details_window(self):
       
        self.window.set_decorated(False)
        self.window.set_resizable(False)
        self.window.set_keep_above(True)
        """i don't what theses two are about"""
        #self.window.set_skip_pager_hint(True)
        #self.window.set_skip_taskbar_hint(True)

        main_vbox = gtk.VBox(False, 0)
        self.window.add(main_vbox)
        
        
        """we build box and label to display info"""
        info_vbox = gtk.VBox(False, 0)
        info_vbox.set_border_width(6)
        main_vbox.add(info_vbox)
        version = self.hella_status['version']
        config_file = self.hella_status['config_file']
        info_1_label = gtk.Label('hellanzb v ' + version + ' - config file : ' + config_file)
        info_vbox.add(info_1_label)
        up_time = str(self.hella_status['uptime'])
        downloaded_nzbs = str(self.hella_status['total_dl_nzbs'])
        downloaded_files = str(self.hella_status['total_dl_files'])
        downloaded_segments = str(self.hella_status['total_dl_segments'])
        info_2_label = gtk.Label('up since : '  + up_time + '   downloaded  ' +  downloaded_nzbs + ' nzbs,  ' + downloaded_files + ' files,  ' + downloaded_segments + ' segments')
        info_vbox.add(info_2_label)
        
        """we build the box and frame to display the currently downloading"""
        if self.hella_status['rate'] == 0:
            cur_down_frame = gtk.Frame('Currently Downloading')
        else:
            cur_down_frame = gtk.Frame('Currently Downloading at %sKb/s' % self.hella_status['rate'])
        main_vbox.add(cur_down_frame)
        cur_down_vbox = gtk.VBox(False, 0)
        cur_down_vbox.set_border_width(6)
        cur_down_frame.add(cur_down_vbox)
        if len(self.hella_status['currently_downloading']) != 0:
            #print "something to download"        #DEBUG
            """we build the pair of labels to display nzb Name"""
            cur_down_name_hbox = gtk.HBox(False, 0)
            cur_down_name_label = gtk.Label('nzb Name :')
            cur_down_name_hbox.pack_start(cur_down_name_label, False, False, 5)
            cur_down_name_data = gtk.Label(self.hella_status['currently_downloading'][0]['nzbName'])
            cur_down_name_hbox.pack_end(cur_down_name_data, False, False, 5)
            cur_down_vbox.add(cur_down_name_hbox)
            """we build the pair of labels to display nzb size"""
            cur_down_size_hbox = gtk.HBox(False, 0)
            cur_down_size_label = gtk.Label('Size :')
            cur_down_size_hbox.pack_start(cur_down_size_label, False, False, 5)
            cur_down_size_data = gtk.Label(str(self.hella_status['currently_downloading'][0]['total_mb']) + 'MB')
            cur_down_size_hbox.pack_end(cur_down_size_data, False, False, 5)
            cur_down_vbox.add(cur_down_size_hbox)
            """we build the pair of labels to display time left"""
            cur_down_time_hbox = gtk.HBox(False, 0)
            cur_down_time_label = gtk.Label('Time Left :')
            cur_down_time_hbox.pack_start(cur_down_time_label, False, False, 5)
            cur_down_time_data = gtk.Label(self.hella_status['eta'])
            cur_down_time_hbox.pack_end(cur_down_time_data, False, False, 5)
            cur_down_vbox.add(cur_down_time_hbox)
            """we build the pair of labels to display percentage completed"""
            cur_down_completed_hbox = gtk.HBox(False, 0)
            cur_down_completed_label = gtk.Label('Percentage Completed :')
            cur_down_completed_hbox.pack_start(cur_down_completed_label, False, False, 5)
            cur_down_completed_data = gtk.Label(str(self.hella_status['percent_complete']) + '%')
            cur_down_completed_hbox.pack_end(cur_down_completed_data, False, False, 5)
            cur_down_vbox.add(cur_down_completed_hbox)
        else:
            #print "nothing to download"        #DEBUG
            """we build the label to display None"""
            cur_down_name_hbox = gtk.HBox(False, 0)
            cur_down_name_label = gtk.Label('None')
            cur_down_name_hbox.pack_start(cur_down_name_label, False, False, 5)
            cur_down_vbox.add(cur_down_name_hbox)
        
        """we build the box and frame to display the queue"""
        queued_frame = gtk.Frame('Queue')
        main_vbox.add(queued_frame)
        queued_vbox = gtk.VBox(False, 0)
        queued_vbox.set_border_width(6)
        queued_frame.add(queued_vbox)
        if len(self.hella_status['queued']) != 0:
            """we build the label to display name and size of each queued nzb"""
            for queued_nzb in self.hella_status['queued']:
                #print 'queued_nzb is %s' % queued_nzb        #DEBUG
                queued_hbox = gtk.HBox(False, 0)
                queued_vbox.add(queued_hbox)
                """we build the nzb name labels pair"""
                queued_name_hbox = gtk.HBox(False, 0)
                queued_name_label = gtk.Label('nzb Name :')
                queued_name_hbox.pack_start(queued_name_label, False, False, 5)
                queued_name_data = gtk.Label(queued_nzb['nzbName'])
                queued_name_hbox.pack_start(queued_name_data, False, False, 5)
                queued_hbox.add(queued_name_hbox)
                """we build the nzb size labels pair"""
                queued_size_hbox = gtk.HBox(False, 0)
                queued_size_data = gtk.Label(str(queued_nzb['total_mb']) + 'MB')
                queued_size_hbox.pack_end(queued_size_data, False, False, 5)
                queued_size_label = gtk.Label('Size :')
                queued_size_hbox.pack_end(queued_size_label, False, False, 5)
                queued_hbox.add(queued_size_hbox)
        else :
            """we build the label to display None"""
            queued_name_hbox = gtk.HBox(False, 0)
            queued_name_label = gtk.Label('None')
            queued_name_hbox.pack_start(queued_name_label, False, False, 5)
            queued_vbox.add(queued_name_hbox)
        
        """we build the box and frame to display the logs"""
        logs_frame = gtk.Frame('Logs')
        main_vbox.add(logs_frame)
        logs_vbox = gtk.VBox(False, 0)
        logs_vbox.set_border_width(6)
        logs_frame.add(logs_vbox)
        for logs in self.hella_status['log_entries']:
            log_hbox = gtk.HBox(False, 0)
            log_label = gtk.Label(logs['INFO'])
            log_hbox.pack_start(log_label, False, False, 5)
            logs_vbox.add(log_hbox)
        
        
        """we tell the rest of the code that the window has been already created"""
        self.created_window = 1

    def position_window(self):
        """this method is from ontv application"""
        self.window.realize()
        gtk.gdk.flush()

        (w, h) = self.window.get_size()
        (w, h) = self.window.size_request()

        (x, y, gravity) = self.get_docking_data(False, w, h)

        self.window.move(x, y)
        self.window.set_gravity(gravity)
    
    def get_docking_data(self, middle, w=0, h=0):
        """this method is from ontv application"""
        self.applet.realize()
        (x, y) = self.applet.window.get_origin()

        button_w = self.applet.allocation.width
        button_h = self.applet.allocation.height

        screen = self.applet.get_screen()

        found_monitor = False
        n = screen.get_n_monitors()
        for i in range(0, n):
            monitor = screen.get_monitor_geometry(i)
            if (x >= monitor.x and x <= monitor.x + monitor.width and
                y >= monitor.y and y <= monitor.y + monitor.height):
                    found_monitor = True
                    break

        if not found_monitor:
            screen_width = screen.get_width()
            monitor = gtk.gdk.Rectangle(0, 0, screen_width, screen_width)

        orient = self.applet.get_orient()

        if orient == gnomeapplet.ORIENT_RIGHT:
            x += button_w

            if ((y + h) > monitor.y + monitor.height):
                y -= (y + h) - (monitor.y + monitor.height)

            if middle:
                x -= button_w/2
                y += button_h/2

            if ((y + h) > (monitor.height / 2)):
                gravity = gtk.gdk.GRAVITY_SOUTH_WEST
            else:
                gravity = gtk.gdk.GRAVITY_NORTH_WEST
        elif orient == gnomeapplet.ORIENT_LEFT:
            x -= w

            if ((y + h) > monitor.y + monitor.height):
                y -= (y + h) - (monitor.y + monitor.height)

            if middle:
                x += w/2
                y += button_h/2

            if ((y + h) > (monitor.height / 2)):
                gravity = gtk.gdk.GRAVITY_SOUTH_EAST
            else:
                gravity = gtk.gdk.GRAVITY_NORTH_EAST
        elif orient == gnomeapplet.ORIENT_DOWN or self.config.standalone:
            y += button_h

            if ((x + w) > monitor.x + monitor.width):
                x -= (x + w) - (monitor.x + monitor.width)

            if middle:
                x += button_w/2
                y -= button_h/2

            gravity = gtk.gdk.GRAVITY_NORTH_WEST
        elif orient == gnomeapplet.ORIENT_UP:
            y -= h

            if ((x + w) > monitor.x + monitor.width):
                x -= (x + w) - (monitor.x + monitor.width)

            if middle:
                x += button_w/2
                y += h/2

            gravity = gtk.gdk.GRAVITY_SOUTH_WEST

        return (x, y, gravity)
         
        
    def get_status_from_server(self):
        """we define the variables used to access hellanb status"""
        server = 'localhost'
        port = '8760'
        server_username = 'hellanzb'
        server_password = 'changeme'
        
        """we build the hellanzb access url"""
        hella_server = ServerProxy('http://' + server_username + ':' + server_password + '@' + server + ':' + port)
        
        """we get hellanzb status"""
        self.hella_status = hella_server.status()
        
    def extract_status(self):
        if len(self.hella_status['currently_downloading']) == 0 and len(self.hella_status['currently_processing']) == 0:
            self.status = 'Nothing to do'
            #print self.status        #DEBUG
        if len(self.hella_status['currently_downloading']) != 0 and len(self.hella_status['currently_processing']) == 0:
            self.status = 'Downloading'
            #print self.status        #DEBUG
        if len(self.hella_status['currently_downloading']) == 0 and len(self.hella_status['currently_processing']) != 0:
            self.status = 'Processing'
            #print self.status        #DEBUG

def create_factory(applet, iid):
    ghellanzb_applet(applet, iid)
    return True

if len(sys.argv) == 2 and sys.argv[1] == "run-in-window":
    #print 'ok we do something'    #DEBUG
    window = gtk.Window(gtk.TOP_LEVEL_WINDOW)
    window.set_title('hellanzb applet')
    window.connect('destroy', gtk.main_quit())
    app = gnomeapplet.Applet()
    create_factory(app, None)
    app.reparent(window)
    window.show_all()
    gtk.main()
    sys.exit()
    
print "Starting factory"
gnomeapplet.bonobo_factory("OAFIID:GNOME_gHellanzbApplet_Factory", gnomeapplet.Applet.__gtype__, "gHellanzb", gHellanzb.version, create_factory)

print "Factory ended"
 
