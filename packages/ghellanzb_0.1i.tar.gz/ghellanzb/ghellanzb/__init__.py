name = "gHellaNzb"
unix_name = 'ghellanzb'
version = "0.1i"
homepage = "http://nicoworkspace.free.fr/?q=ghellanzb-downloads"
author = "Nicolas Delebecque"
author_mail = "nicolas.delebecque@gmail.com"
licence = "GNU/GPL"
description = "gHellaNzb is a small gnome applet monitoring HellaNzb"
platform = "unix"
images_dir = "/usr/share/ghellanzb/images"
ui_dir = '/usr/share/gnome-2.0/ui'
