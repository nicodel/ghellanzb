name = "gHellaNzb"
unix_name = 'ghellanzb'
version = "0.1e"
homepage = "http://nicoworkspace.free.fr/?q=ghellanzb-downloads"
author = "Nicolas Delebecque"
author_mail = "nicolas.delebecque@gmail.com"
licence = "GNU/GPL"
description = "gHellaNzb is a small gnome applet monitoring HellaNzb"
platform = "unix"
